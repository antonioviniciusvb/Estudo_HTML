window.onload = function(){
	
	document.getElementById('box1').onclick = function(){
		alert('ok!');
	}
}